app.controller("MainCtrl", ["$scope", "weatherService", function ($scope, weather) {
	// Declare
	$scope.cityName = "Hanoi";
	$scope.weatherData = {};
	
	// Execute

	// Event

	// Other function
	$scope.getData = function (cityName) {
		weather.getData(cityName, function (data) {
			$scope.weatherData = data;
		});
	}
	
	$scope.getData($scope.cityName);
}])

