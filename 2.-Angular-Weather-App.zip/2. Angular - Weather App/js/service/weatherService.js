app.factory("weatherService", ['$http', function ($http) {
	return {
		getData: function (cityName, fnSuccess, fnError) {
			var url = 'http://api.openweathermap.org/data/2.5/weather?q=' + cityName + '&units=metric';

			$http.get(url).then(function (response) {
				fnSuccess(response.data);
			}, function (response) {
				console.log("Have some errors when get data from service")
			})
		}
	}
}])