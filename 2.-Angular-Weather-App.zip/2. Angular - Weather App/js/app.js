var app = angular.module("WeatherApp", []);

app.config(['$httpProvider', function ($httpProvider) {

}])